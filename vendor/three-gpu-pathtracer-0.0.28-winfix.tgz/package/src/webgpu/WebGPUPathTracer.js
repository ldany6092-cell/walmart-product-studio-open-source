import { Box3, DataTexture, EventDispatcher, LinearFilter, MathUtils, Vector2, Scene, PerspectiveCamera, Color, NoToneMapping, FloatType, Timer, StorageTexture, MeshBasicNodeMaterial, Matrix4, WebGPUCoordinateSystem } from 'three/webgpu';
import { uv, uniform, varying } from 'three/tsl';
import { SkinnedMeshBVH, MeshBVH, SAH } from 'three-mesh-bvh';
import { ndcToCameraRay, rayStruct, wgslTagFn } from 'three-mesh-bvh/webgpu';
import { FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js';
import { RenderToScreenNodeMaterial } from './materials/RenderToScreenMaterial.js';
import { getDebugBoundsFunction } from './nodes/debugBounds.wgsl.js';
import { MegaKernelPathTracer } from './MegaKernelPathTracer.js';
import { WaveFrontPathTracer } from './WaveFrontPathTracer.js';
import { CubeToEquirectGenerator } from '../utils/CubeToEquirectGenerator.js';
import { PathtracerBVHComputeData } from './nodes/PathtracerBVHComputeData.js';
import { AtlasDebugMaterial } from './materials/debug/AtlasDebugMaterial.js';
import { SampleDensityMaterial } from './materials/debug/SampleDensityMaterial.js';
import { AuxDebugMaterial } from './materials/debug/AuxDebugMaterial.js';
import { setCommonAttributes } from '../core/utils/GeometryPreparationUtils.js';
import { getLights } from '../core/utils/sceneUpdateUtils.js';
import { GLTFShadingModel } from './shadingModels/GLTFShadingModel.js';
import { TRANSMISSIVE_BACKGROUND_OVERLAY, RANDOM_SOBOL } from './constants.js';
/** @import { Camera, Scene, Texture, WebGPURenderer } from 'three/webgpu' */
/** @import { AtlasTexture } from './AtlasTexture.js' */
/** @import { OIDNDenoiser } from './denoise/OIDNDenoiser.js' */
/** @import { FSRUpscaler } from './upscale/FSRUpscaler.js' */
/** @import { ShadingModel } from './shadingModels/ShadingModel.js' */

/**
 * @typedef {Object} SampleCounts
 * @property {number} min - Lowest sample count of any pixel.
 * @property {number} max - Highest sample count of any pixel.
 * @property {number} avg - Mean sample count across the image.
 * @property {number} samplesPerSecond - Mean samples accumulated per second since the last reset.
 */

const _resolution = new Vector2();
const _color = new Color();

// milliseconds between sample count readbacks while waiting for the render to complete
const COMPLETE_CHECK_INTERVAL = 250;

// How the adaptive frame budget follows the measured frame time. The budget is only reconsidered once
// a window of measurements has been taken at it, and only changes when their average is off the target
// by the threshold ratio, since a wavefront budget change reallocates the path buffers. It moves at most
// the step ratio per window.
// TODO: adapt more often, with a window of around 4, once the wavefront path buffers are grow-only so a budget
// change only changes the active slot count rather than reallocating them
const BUDGET_WINDOW = 16;
const BUDGET_CHANGE_THRESHOLD = 1.15;
const BUDGET_MAX_STEP = 2;
const MIN_FRAME_BUDGET = 4096;

// the options the mesh geometry bvhs are built with and how many workers build them at once
const MESH_BVH_OPTIONS = { strategy: SAH, targetLeafSize: 5 };
const MAX_BVH_WORKERS = 4;

// the stages before a scene renders, in order
const STAGE_BUILDING = 0;
const STAGE_COMPILING = 1;
const STAGE_RENDERING = 2;

// Builds a geometry's BVH in a worker without giving up its buffers. The workers transfer the position and
// index buffers, which neuters them for every other array viewing them, such as the attributes of other
// meshes in a glTF. So the worker gets copies, the original arrays are restored, and the reordered index
// is written back into the original. Shared array buffers aren't transferred, so they're sent as is.
// TODO: this is imperfect, and depends on how the worker transfers. Remove once three-mesh-bvh's worker
// has an option not to transfer
async function generateBVHInWorker( worker, geometry, options ) {

	const getCopy = array => {

		const isShared = typeof SharedArrayBuffer !== 'undefined' && array.buffer instanceof SharedArrayBuffer;
		return isShared ? array : array.slice();

	};

	const { position } = geometry.attributes;
	const { index } = geometry;
	const positionArray = position.array;
	const indexArray = index ? index.array : null;

	position.array = getCopy( positionArray );
	if ( index ) {

		index.array = getCopy( indexArray );

	}

	const bvh = await worker.generate( geometry, options );

	position.array = positionArray;
	if ( index ) {

		indexArray.set( index.array );
		index.array = indexArray;
		index.needsUpdate = true;

	}

	return bvh;

}

class TextureCache {

	constructor( renderer, key ) {

		this.key = key;
		this.renderer = renderer;
		this.texture = null;
		this.hash = null;

		const colorTex = new DataTexture( new Uint8Array( [ 255, 255, 255, 255 ] ), 1, 1 );
		colorTex.minFilter = LinearFilter;
		colorTex.magFilter = LinearFilter;
		this.colorTex = colorTex;

	}

	dispose() {

		this.colorTex.dispose();
		this.texture?.dispose();

	}

	setFromScene( scene ) {

		const { renderer, key, colorTex } = this;
		let value = scene[ key ];
		let hash = '';

		if ( ! value ) {

			const clearAlpha = renderer.getClearAlpha();
			renderer.getClearColor( _color );

			colorTex.image.data[ 0 ] = _color.r * 255;
			colorTex.image.data[ 1 ] = _color.g * 255;
			colorTex.image.data[ 2 ] = _color.b * 255;
			colorTex.image.data[ 3 ] = clearAlpha * 255;

			value = colorTex;
			hash = colorTex.image.data.join();
			colorTex.needsUpdate = hash !== this.hash;

		} else if ( value.isColor ) {

			colorTex.image.data[ 0 ] = value.r * 255;
			colorTex.image.data[ 1 ] = value.g * 255;
			colorTex.image.data[ 2 ] = value.b * 255;
			colorTex.image.data[ 3 ] = 255;

			value = colorTex;
			hash = colorTex.image.data.join();
			colorTex.needsUpdate = hash !== this.hash;

		} else if ( value.isCubeTexture ) {

			hash = null;
			value = new CubeToEquirectGenerator( renderer ).generate( value );

		} else {

			// hash the scene's texture rather than the clone, whose uuid is new on every call, so an
			// unchanged texture isn't cloned and re-processed each time the environment is updated
			hash = value.uuid + '_' + value.version;
			if ( hash !== this.hash ) {

				// a nearest filtered texture gets no sampler from TSL, which the equirect sampling
				// needs, so the copy is always filtered
				value = value.clone();
				value.minFilter = LinearFilter;
				value.magFilter = LinearFilter;

			}

		}

		if ( hash === null ) {

			this.texture?.dispose();

			this.texture = value;
			this.hash = null;
			return true;

		} else {

			const needsUpdate = hash !== this.hash;
			if ( needsUpdate ) {

				this.texture?.dispose();
				this.texture = value;
				this.hash = hash;

			}

			return needsUpdate;

		}

	}

}

// WebGPUPathTracer Event Definitions

/**
 * Fired once every pixel has reached `maxSamples` and an attached denoiser has finished. Fires
 * again after a reset, or after `maxSamples` is raised, once the render has caught up.
 * @event WebGPUPathTracer#complete
 */

/**
 * Fired as the render advances. `stage` is "building", "compiling", "rendering" or "denoising", and
 * `progress` is the fraction of it done, or null when unknown. "rendering" also gives the sample
 * counts as `samples`, reported a few times a second.
 * @event WebGPUPathTracer#progress
 */

/**
 * Progressive path tracer running on WebGPU. Call {@link WebGPUPathTracer#setScene} once,
 * then {@link WebGPUPathTracer#renderSample} every frame to accumulate samples into the canvas.
 *
 * The scene is captured when `setScene` is called, so changes to geometry, materials, lights, or
 * the environment afterward require the matching `update*` function. Any change that invalidates
 * the accumulated image restarts it.
 */
export class WebGPUPathTracer extends EventDispatcher {

	/**
	 * Maximum number of times a ray can scatter before the path is terminated. Higher values
	 * resolve more indirect light at the cost of speed.
	 * @type {number}
	 * @default 15
	 */
	get maxBounces() {

		return this._pathTracer.maxBounces;

	}

	set maxBounces( v ) {

		this._pathTracer.maxBounces = v;
		this.reset();

	}

	/**
	 * Number of path steps dispatched per {@link WebGPUPathTracer#renderSample} call,
	 * independent of resolution. Raising it trades frame rate for convergence speed.
	 * @type {number}
	 * @default 250000
	 */
	get frameBudget() {

		return this._pathTracer.frameBudget;

	}

	set frameBudget( v ) {

		this._pathTracer.frameBudget = v;

	}

	/**
	 * GPU time in milliseconds of a recent {@link WebGPUPathTracer#renderSample} call. Only measured
	 * when the renderer is created with `trackTimestamp: true`.
	 * @type {number}
	 * @readonly
	 */
	get frameTime() {

		return this._pathTracer.timing.frameTime;

	}

	/**
	 * Maximum number of alpha tested surfaces a ray can pass through. Counted separately from
	 * {@link WebGPUPathTracer#maxBounces} so foliage and cutouts cannot exhaust the bounce budget.
	 * @type {number}
	 * @default 15
	 */
	get maxTransparentBounces() {

		return this._pathTracer.maxTransparentBounces;

	}

	set maxTransparentBounces( v ) {

		this._pathTracer.maxTransparentBounces = v;
		this.reset();

	}

	/**
	 * Maximum number of scatter events a path can take inside a subsurface scattering volume. Counted
	 * separately from {@link WebGPUPathTracer#maxBounces}. Paths that reach it end, darkening dense volumes.
	 * @type {number}
	 * @default 256
	 */
	get maxSubsurfaceBounces() {

		return this._pathTracer.maxSubsurfaceBounces;

	}

	set maxSubsurfaceBounces( v ) {

		this._pathTracer.maxSubsurfaceBounces = v;
		this.reset();

	}

	/**
	 * Stops accumulating once every pixel reaches this many samples. A denoiser only runs once the
	 * render has stopped, so it has no effect while this is `0`.
	 * @type {number}
	 * @default 0
	 * @note `0` renders indefinitely.
	 */
	get maxSamples() {

		return this._pathTracer.maxSamples;

	}

	set maxSamples( v ) {

		this._pathTracer.maxSamples = v;

		// the settle point moved, so a finished pass may need to run again against a longer
		// render. The accumulated samples are still valid
		this._denoiser?.reset();

	}

	/**
	 * Whether every pixel has reached {@link WebGPUPathTracer#maxSamples} and an attached denoiser
	 * has finished, as of the last measurement. Always false while rendering indefinitely.
	 * @type {boolean}
	 */
	get complete() {

		const maxSamples = this.maxSamples;
		const denoiser = this._denoiser;

		// "min" so every pixel has stopped, not just the average
		return maxSamples > 0 && this._lastSampleCounts.min >= maxSamples && ( ! denoiser || denoiser.complete );

	}

	/**
	 * Measures the per pixel sample counts. Use `min` for convergence checks and `avg` to display.
	 * @returns {Promise<SampleCounts>}
	 * @note The wavefront backend reduces the counts on the GPU and reads them back, so only call
	 *   this when the numbers are needed.
	 */
	async getSampleCountsAsync() {

		const pathTracer = this._pathTracer;

		// written in place. reset swaps in a new object so a late measurement can't overwrite it.
		const counts = this._lastSampleCounts;
		const measured = await pathTracer.getSampleCountsAsync();

		counts.min = measured.min;
		counts.max = measured.max;
		counts.avg = measured.avg;

		// averaged over the whole render, and idle time counts against it
		const elapsed = this.getRenderTime() / 1000;
		counts.samplesPerSecond = elapsed > 0 ? counts.avg / elapsed : 0;

		return { ...counts };

	}

	/**
	 * How the background is treated behind transmissive surfaces. One of
	 * `TRANSMISSIVE_BACKGROUND_OVERLAY`, `TRANSMISSIVE_BACKGROUND_ENVIRONMENT`, or
	 * `TRANSMISSIVE_BACKGROUND_TRANSPARENT`.
	 * @type {number}
	 * @default TRANSMISSIVE_BACKGROUND_OVERLAY
	 */
	get transmissiveBackground() {

		return this._transmissiveBackground;

	}

	set transmissiveBackground( v ) {

		if ( this._transmissiveBackground !== v ) {

			this._transmissiveBackground = v;
			this._pathTracer.setTransmissiveBackground( v );

		}

	}

	/**
	 * Blurs sharp reflections seen through rough surfaces to suppress fireflies. Higher values
	 * remove more noise and more detail.
	 * @type {number}
	 * @default 1
	 * @note `0` disables the filter.
	 */
	get filterGlossyFactor() {

		return this._filterGlossyFactor;

	}

	set filterGlossyFactor( v ) {

		if ( this._filterGlossyFactor !== v ) {

			this._filterGlossyFactor = v;
			this._pathTracer.setFilterGlossy( v );

		}

	}

	/**
	 * Whether to combine light sampling and bsdf sampling with MIS. Disabling it makes lights
	 * noticeably noisier.
	 * @type {boolean}
	 * @default true
	 */
	get multipleImportanceSampling() {

		return this._multipleImportanceSampling;

	}

	set multipleImportanceSampling( v ) {

		if ( this._multipleImportanceSampling !== v ) {

			this.setMultipleImportanceSampling( v );

		}

	}

	/**
	 * Upper bound on the contribution of a directly lit path segment, for suppressing fireflies.
	 * @type {number}
	 * @default 0
	 * @note `0` disables the clamp. Clamping darkens the image and biases the result.
	 */
	get clampDirect() {

		return this._clampDirect;

	}

	set clampDirect( v ) {

		v = Math.max( 0, v );
		if ( this._clampDirect !== v ) {

			this._clampDirect = v;
			this._pathTracer.setClamping( v, this._clampIndirect );

		}

	}

	/**
	 * Upper bound on the contribution of an indirectly lit path segment, for suppressing
	 * fireflies.
	 * @type {number}
	 * @default 10
	 * @note `0` disables the clamp. Clamping darkens the image and biases the result.
	 */
	get clampIndirect() {

		return this._clampIndirect;

	}

	set clampIndirect( v ) {

		v = Math.max( 0, v );
		if ( this._clampIndirect !== v ) {

			this._clampIndirect = v;
			this._pathTracer.setClamping( this._clampDirect, v );

		}

	}

	/**
	 * The render target the accumulated samples are written into.
	 * @type {Texture|null}
	 * @readonly
	 */
	get target() {

		return this._pathTracer.outputTarget ?? null;

	}

	/**
	 * Progress of the fade from the low resolution preview to the full render, from 0 to 1.
	 * @type {number}
	 * @readonly
	 */
	get fadeState() {

		return this._fadeState;

	}

	/**
	 * The low resolution preview rendered while {@link WebGPUPathTracer#renderDelay} elapses.
	 * @type {Texture}
	 * @readonly
	 */
	get lowResTarget() {

		return this._lowResTarget;

	}

	/**
	 * Whether the tracer is currently rendering the low resolution preview.
	 * @type {boolean}
	 * @readonly
	 */
	get lowResMode() {

		return this._pathTracer.lowResMode;

	}

	/**
	 * Whether the kernels are compiling, such as after the scene or material changes. Nothing new
	 * renders until they finish and the canvas keeps the last frame, so an app may draw its own
	 * preview in the meantime.
	 * @type {boolean}
	 * @readonly
	 */
	get compiling() {

		return this._pathTracer.compiling;

	}

	/**
	 * The atlas every scene texture is packed into for the kernels to sample.
	 * @type {AtlasTexture}
	 * @readonly
	 */
	get textureAtlas() {

		return this._shadingModel.textureAtlas;

	}

	/**
	 * Switches between the two tracing backends and rebuilds the kernels. The wavefront backend is
	 * used by default and is faster on most scenes.
	 *
	 * @param {boolean} value - `true` for the megakernel, `false` for the wavefront tracer.
	 * @private
	 */
	useMegakernel( value ) {

		const maxSamples = this._pathTracer.maxSamples;

		this._pathTracer.dispose();
		this._pathTracer = value ? new MegaKernelPathTracer( this._renderer ) : new WaveFrontPathTracer( this._renderer );
		this._pathTracer.maxSamples = maxSamples;
		this._timingCount = 0;
		this._pathTracer.setBVHData( this._bvhData );
		this._pathTracer.setShadingModel( this._shadingModel );
		this._pathTracer.setRandom( this._random );
		this._pathTracer.setMultipleImportanceSampling( this.multipleImportanceSampling );
		this._pathTracer.setTransmissiveBackground( this._transmissiveBackground );
		this._pathTracer.setFilterGlossy( this._filterGlossyFactor );
		this._pathTracer.setClamping( this._clampDirect, this._clampIndirect );
		this._pathTracer.setAccumulateAux( Boolean( this._denoiser && this._denoiser.useAuxiliaryBuffers ) );
		this.setCamera( this.camera );

		// the new tracer has default environment and background maps so apply the cached scene textures
		this._pathTracer.setEnvironment( this._environmentCache.texture );
		this._pathTracer.setBackground( this._backgroundCache.texture );
		this.updateEnvironment();
		this.updateLights();

	}

	/**
	 * @param {WebGPURenderer} renderer
	 */
	constructor( renderer ) {

		super();

		// members
		this._renderer = renderer;
		this._timer = new Timer();

		this._environmentCache = new TextureCache( renderer, 'environment' );
		this._backgroundCache = new TextureCache( renderer, 'background' );

		this._resetTime = - 1;
		this._fadeState = 0;
		this._lastSampleCounts = { min: 0, max: 0, avg: 0, samplesPerSecond: 0 };
		this._size = new Vector2();
		this._blitQuad = new FullScreenQuad( new RenderToScreenNodeMaterial() );

		// adaptive frame budget and preview state
		this._timingCount = 0;
		this._frameTimeTotal = 0;
		this._frameTimeCount = 0;
		this._warnedTimestamps = false;

		// the budget from before the first pixels finished, restored on reset. The last few pixels render
		// quickly and inflate the budget
		this._fullFrameBudget = null;

		// avoid mipmap gen on copy, not always supported with float type
		this._lowResTarget = new StorageTexture( 1, 1 );
		this._lowResTarget.type = FloatType;
		this._lowResTarget.generateMipmaps = false;

		this._pathTracer = new WaveFrontPathTracer( renderer );

		// optional post passes, attached with "setDenoiser" / "setUpscaler"
		this._denoiser = null;
		this._upscaler = null;

		// the attached denoiser's progress events are forwarded
		this._onDenoiserProgress = e => this.dispatchEvent( { type: 'progress', stage: 'denoising', progress: e.progress } );

		// the current stage. Only the latest "setSceneAsync" call sets its scene, and a geometry already building
		// for an earlier call is awaited rather than built again
		this._stage = STAGE_RENDERING;
		this._sceneRequest = 0;
		this._pendingBVHs = new WeakMap();

		// options

		/**
		 * Average samples per pixel the full resolution render must reach before it is faded in.
		 * @type {number}
		 * @default 1
		 */
		this.minSamples = 1;

		/**
		 * Milliseconds to show the low resolution preview for after a reset.
		 * @type {number}
		 * @default 16
		 */
		this.renderDelay = 16;

		/**
		 * Milliseconds taken to cross fade from the preview to the full render.
		 * @type {number}
		 * @default 250
		 */
		this.fadeDuration = 250;

		/**
		 * Whether to render a low resolution preview while the camera is moving.
		 * @type {boolean}
		 * @default true
		 */
		this.dynamicLowRes = true;

		/**
		 * Resolution of the low resolution preview, as a fraction of the render size. Adjusted when
		 * {@link WebGPUPathTracer#adaptiveDynamicRes} is set. The preview never has more pixels than a
		 * frame of {@link WebGPUPathTracer#frameBudget} can render.
		 * @type {number}
		 * @default 0.1
		 */
		this.lowResScale = 0.1;

		/**
		 * Whether {@link WebGPUPathTracer#lowResScale} is adjusted to the pixels a frame of
		 * {@link WebGPUPathTracer#frameBudget} can render.
		 * @type {boolean}
		 * @default true
		 */
		this.adaptiveDynamicRes = true;

		/**
		 * Whether {@link WebGPUPathTracer#frameBudget} is adjusted to keep each
		 * {@link WebGPUPathTracer#renderSample} call near {@link WebGPUPathTracer#targetFrameTime} of
		 * GPU time. Requires a renderer created with `trackTimestamp: true`.
		 * @type {boolean}
		 * @default true
		 */
		this.adaptiveFrameBudget = true;

		/**
		 * GPU time in milliseconds per frame targeted by {@link WebGPUPathTracer#adaptiveFrameBudget}.
		 * @type {number}
		 * @default 16
		 */
		this.targetFrameTime = 16;

		/**
		 * Resolution the path tracer renders at, as a fraction of the canvas size. Lowering it
		 * converges faster at the cost of detail, and pairs with an upscaler.
		 * @type {number}
		 * @default 1
		 */
		this.renderScale = 1;

		/**
		 * Whether to track the canvas size automatically. Set to `false` to drive the render
		 * size with {@link WebGPUPathTracer#setSize}.
		 * @type {boolean}
		 * @default true
		 */
		this.synchronizeRenderSize = true;

		/**
		 * Whether {@link WebGPUPathTracer#renderSample} draws the result to the current render
		 * target, the canvas by default. Set to `false` to only accumulate, as when baking to a
		 * texture read through {@link WebGPUPathTracer#target}.
		 * @type {boolean}
		 * @default true
		 */
		this.renderToCanvas = true;

		/**
		 * Whether to compile the kernels asynchronously so a compile doesn't stall the page. Nothing
		 * new renders while {@link WebGPUPathTracer#compiling} is true.
		 * @type {boolean}
		 * @default false
		 */
		this.asyncCompile = false;

		/**
		 * Whether to generate the attributes in {@link WebGPUPathTracer#commonAttributes} on
		 * geometry that is missing them when the scene is set.
		 * @type {boolean}
		 * @default true
		 */
		this.generateMissingAttributes = true;

		/**
		 * Vertex attributes every geometry is expected to provide.
		 * @type {Array<string>}
		 * @default [ 'normal', 'tangent' ]
		 */
		this.commonAttributes = [ 'normal', 'tangent' ];

		/**
		 * Whether to restart the random sequence on reset so a given camera always produces the
		 * same image.
		 * @type {boolean}
		 * @default true
		 */
		this.stableNoise = true;

		/**
		 * Whether to stop accumulating samples. The last image keeps being presented.
		 * @type {boolean}
		 * @default false
		 */
		this.pause = false;

		this.filterGlossyFactor = 1;
		this._clampDirect = 0;
		this._clampIndirect = 10;
		this.multipleImportanceSampling = true;
		this.transmissiveBackground = TRANSMISSIVE_BACKGROUND_OVERLAY;

		/**
		 * Random number generator the kernels sample with.
		 * @type {Object}
		 * @private
		 */
		this._random = RANDOM_SOBOL;

		/**
		 * Shading model the kernels evaluate surfaces with.
		 * @type {ShadingModel}
		 * @private
		 */
		this._shadingModel = new GLTFShadingModel();

		// default camera ray generation ( perspective / orthographic ), assigned onto each bvh compute
		// data's fns so the kernels can proxy it. The uniform is the inverse view-projection
		// ( world * inverseProjection ), premultiplied on the CPU so no matrix multiply runs per ray.
		this._invViewProjectionMatrix = uniform( new Matrix4() );
		this._cameraRayFnHandle = null;
		this._BVHWorker = null;

		// the render time of the last check for the render having stopped
		this._lastCompleteCheck = 0;
		this._wasComplete = false;

		// initialize the scene so it doesn't fail
		this.setShadingModel( this._shadingModel );
		this.setRandom( this._random );
		this.setScene( new Scene(), new PerspectiveCamera() );

	}

	/**
	 * @param {boolean} value
	 */
	setMultipleImportanceSampling( value ) {

		this._multipleImportanceSampling = value;
		this._pathTracer.setMultipleImportanceSampling( value );
		this.reset();

	}

	/**
	 * Attaches a denoiser, run once the render settles and displayed in place of the raw image.
	 * Settings live on the instance. Pass null to remove it. The render restarts when the auxiliary
	 * buffers it needs are added or dropped.
	 *
	 * @param {OIDNDenoiser|null} denoiser
	 */
	setDenoiser( denoiser ) {

		// a detached instance stops receiving resets, so clear it rather than let it hold a
		// result from a camera position that has since moved
		this._denoiser?.reset();
		this._denoiser?.removeEventListener( 'progress', this._onDenoiserProgress );
		this._denoiser = denoiser;

		if ( denoiser ) {

			denoiser.init( this._renderer );
			denoiser.addEventListener( 'progress', this._onDenoiserProgress );

		}

		this._pathTracer.setAccumulateAux( Boolean( denoiser && denoiser.useAuxiliaryBuffers ) );
		this.reset();

	}

	/**
	 * Attaches an upscaler, run before the image is presented so the render can happen below the
	 * canvas resolution. Settings live on the instance. Pass null to remove it.
	 *
	 * @param {FSRUpscaler|null} upscaler
	 */
	setUpscaler( upscaler ) {

		this._upscaler = upscaler;

		if ( upscaler ) {

			upscaler.init( this._renderer );

		}

	}

	/**
	 * Captures the scene and camera and builds the acceleration structures the kernels trace
	 * against. Call this once, then use the `update*` functions for later changes.
	 *
	 * @param {Scene} scene
	 * @param {Camera} camera
	 * @note Geometry BVHs are built synchronously, so this blocks for large scenes.
	 */
	setScene( scene, camera ) {

		scene.updateMatrixWorld( true );
		camera.updateMatrixWorld();

		// Build BVH for each mesh geometry
		scene.traverse( child => {

			if ( this.generateMissingAttributes && child.geometry?.isBufferGeometry ) {

				setCommonAttributes( child.geometry, this.commonAttributes );

			}

			if ( child.isSkinnedMesh ) {

				if ( ! child.boundsTree ) {

					child.boundsTree = new SkinnedMeshBVH( child, { strategy: SAH, targetLeafSize: 5, indirect: true } );

				} else {

					child.boundsTree.refit();

				}

				if ( child.boundingBox === null ) {

					child.boundingBox = new Box3();

				}

				child.boundsTree.getBoundingBox( child.boundingBox );

			} else if ( child.isMesh ) {

				if ( ! child.geometry.boundsTree ) {

					child.geometry.boundsTree = new MeshBVH( child.geometry, MESH_BVH_OPTIONS );

				}

			}

		} );

		// the materials are written first since the bvh data writes their indices with the transforms
		const { _shadingModel: shadingModel } = this;
		shadingModel.updateMaterials( scene );

		// Build TLAS and compute functions
		const bvhData = new PathtracerBVHComputeData( scene, shadingModel );
		bvhData.update();
		shadingModel.updateTextures( this._renderer );

		if ( this._bvhData ) {

			this._bvhData.dispose();

		}

		this.scene = scene;
		this._bvhData = bvhData;
		this._pathTracer.setBVHData( bvhData );
		this.setCamera( camera );
		this.updateEnvironment();
		this.updateLights();

	}

	/**
	 * Sets the worker class {@link WebGPUPathTracer#setSceneAsync} builds the mesh geometry BVHs
	 * with, such as `GenerateMeshBVHWorker` from three-mesh-bvh. Several are created and disposed
	 * per call so geometries build in parallel.
	 *
	 * @param {Function} WorkerConstructor
	 */
	setBVHWorker( WorkerConstructor ) {

		this._BVHWorker = WorkerConstructor;

	}

	/**
	 * Like {@link WebGPUPathTracer#setScene} but builds the mesh geometry BVHs in the workers set
	 * with {@link WebGPUPathTracer#setBVHWorker} so the page is not blocked. Skinned meshes are
	 * still built synchronously.
	 *
	 * @param {Scene} scene
	 * @param {Camera} camera
	 * @returns {Promise<void>}
	 */
	async setSceneAsync( scene, camera ) {

		const WorkerConstructor = this._BVHWorker;
		if ( ! WorkerConstructor ) {

			throw new Error( 'WebGPUPathTracer: "setBVHWorker" must be called before "setSceneAsync" can be called.' );

		}

		this._sceneRequest ++;

		const request = this._sceneRequest;
		const pendingBVHs = this._pendingBVHs;

		// the worker doesn't support interleaved attributes, so those geometries are built in "setScene" instead
		const geometries = new Set();
		const pending = new Set();
		scene.traverse( child => {

			if ( child.isMesh && ! child.isSkinnedMesh && ! child.geometry.boundsTree ) {

				const { geometry } = child;
				if ( geometry.attributes.position.isInterleavedBufferAttribute || geometry.index && geometry.index.isInterleavedBufferAttribute ) {

					return;

				}

				if ( pendingBVHs.has( geometry ) ) {

					pending.add( pendingBVHs.get( geometry ) );

				} else {

					geometries.add( geometry );

				}

			}

		} );

		// each worker runs one job at a time so they pull from a shared queue
		const queue = Array.from( geometries );

		// build progress, weighted by triangle count
		const getTriangleCount = geometry => ( geometry.index ? geometry.index.count : geometry.attributes.position.count ) / 3;
		const totalTriangles = queue.reduce( ( sum, geometry ) => sum + getTriangleCount( geometry ), 0 );
		let builtTriangles = 0;

		const workers = [];
		for ( let i = 0, l = Math.min( MAX_BVH_WORKERS, queue.length ); i < l; i ++ ) {

			workers.push( new WorkerConstructor() );

		}

		// stop rendering the previous scene while the next one builds, keeping the last frame. The denoiser runs
		// its tiles on its own schedule, so it's reset separately
		this._setStage( STAGE_BUILDING );
		this._denoiser?.reset();

		try {

			await Promise.all( [ ...pending, ...workers.map( async worker => {

				while ( queue.length > 0 ) {

					const geometry = queue.shift();
					const triangles = getTriangleCount( geometry );
					let reported = 0;
					const onProgress = progress => {

						builtTriangles += ( progress - reported ) * triangles;
						reported = progress;

						// skip if a later call replaced this scene
						if ( request === this._sceneRequest ) {

							this.dispatchEvent( { type: 'progress', stage: 'building', progress: builtTriangles / totalTriangles } );

						}

					};

					const promise = generateBVHInWorker( worker, geometry, { ...MESH_BVH_OPTIONS, onProgress } );
					pendingBVHs.set( geometry, promise );

					try {

						geometry.boundsTree = await promise;
						onProgress( 1 );

					} finally {

						pendingBVHs.delete( geometry );

					}

				}

			} ) ] );

		} finally {

			workers.forEach( worker => worker.dispose() );
			if ( request === this._sceneRequest ) {

				this._setStage( STAGE_COMPILING );

			}

		}

		// skip the scene if a later call replaced it while it built
		if ( request === this._sceneRequest ) {

			this.setScene( scene, camera );

		}

	}

	/**
	 * @returns {ShadingModel}
	 * @private
	 */
	getShadingModel() {

		return this._shadingModel;

	}

	/**
	 * Replaces the shading model and recompiles the kernels.
	 *
	 * @param {ShadingModel} shadingModel
	 * @private
	 */
	setShadingModel( shadingModel ) {

		this._shadingModel = shadingModel;
		shadingModel.updateFunctions();

		// the shading model writes the materials, so rewrite them in its struct
		const { _bvhData, _renderer, scene } = this;
		if ( _bvhData ) {

			shadingModel.updateMaterials( scene );
			shadingModel.updateTextures( _renderer );
			_bvhData.setShadingModel( shadingModel );

		}

		this._pathTracer.setShadingModel( shadingModel );
		this.reset();

	}

	/**
	 * Replaces the random number generator and recompiles the kernels.
	 *
	 * @param {Object} random - One of the Random Strategies constants, such as `RANDOM_BLUE_DITHER`.
	 */
	setRandom( random ) {

		this._random = random;
		this._pathTracer.setRandom( random );
		this.reset();

	}

	/**
	 * Replaces the camera the rays are generated from. Cameras with a `getCameraRayFn`, such as
	 * `PhysicalCamera` and `EquirectCamera`, provide their own ray generation.
	 *
	 * @param {Camera} camera
	 */
	setCamera( camera ) {

		this.camera = camera;

		if ( camera.getCameraRayFn ) {

			this._cameraRayFnHandle = camera.getCameraRayFn();

		} else {

			// add a default camera ray getter. the update function is called when the camera is
			// updated to trigger any necessary uniform updates.
			const invViewProjectionMatrix = this._invViewProjectionMatrix;
			this._cameraRayFnHandle = {
				update: () => {

					camera.coordinateSystem = WebGPUCoordinateSystem;
					camera.updateMatrixWorld();

					if ( camera.isOrthographicCamera || camera.isPerspectiveCamera ) {

						camera.updateProjectionMatrix();

					}

					invViewProjectionMatrix.value.multiplyMatrices( camera.matrixWorld, camera.projectionMatrixInverse );
					return false;

				},
				fn: wgslTagFn/* wgsl */`
					fn getCameraRay( uv: vec2f, resolution: vec2f, ray: ptr<function, ${ rayStruct }> ) -> bool {

						let ndc = uv * 2.0 - vec2f( 1.0 );
						*ray = ${ ndcToCameraRay }( ndc, ${ invViewProjectionMatrix } );
						return true;

					}
				`,
			};

		}

		this._bvhData.fns.getCameraRay = this._cameraRayFnHandle.fn;
		this._cameraRayFnHandle.update();
		this._pathTracer.rebuild();
		this.reset();

	}

	/**
	 * Re-reads the material properties and textures from the scene. Call after changing any
	 * material.
	 */
	updateMaterials() {

		const { _bvhData, _renderer, _shadingModel, scene } = this;
		_shadingModel.updateMaterials( scene );
		_bvhData.updateMaterialIndices();

		// the kernels size the texture info when they're built, so a new texture count needs a rebuild
		if ( _shadingModel.updateTextures( _renderer ) ) {

			this._pathTracer.rebuild();

		}

		this.reset();

	}

	/**
	 * Re-reads the world matrices from the scene. Call after moving any object.
	 * @note Changing geometry requires {@link WebGPUPathTracer#setScene} instead, since the BVH
	 *   must be rebuilt.
	 */
	updateTransforms() {

		this.scene.updateMatrixWorld( true );
		this._bvhData.updateTransforms();
		this.reset();

	}

	/**
	 * Re-reads the camera transform and projection. Call after moving the camera.
	 */
	updateCamera() {

		const { _cameraRayFnHandle, _pathTracer } = this;
		if ( _cameraRayFnHandle.update() ) {

			_pathTracer.rebuild();

		}

		this.reset();

	}

	/**
	 * Re-reads `scene.environment` and `scene.background`, along with their intensity, rotation,
	 * and blur.
	 */
	updateEnvironment() {

		const {
			_pathTracer,
			scene,

			_environmentCache,
			_backgroundCache,
		} = this;

		// update the texture if they've changed
		if ( _environmentCache.setFromScene( scene ) ) {

			_pathTracer.setEnvironment( _environmentCache.texture );

		}

		if ( _backgroundCache.setFromScene( scene ) ) {

			_pathTracer.setBackground( _backgroundCache.texture );

		}

		// update the params always since they're cheap
		_pathTracer.setEnvironmentParams(
			scene.environmentIntensity,
			scene.environmentRotation,
		);

		_pathTracer.setBackgroundParams(
			scene.backgroundIntensity,
			scene.backgroundRotation,
			scene.backgroundBlurriness,
		);

		this.reset();

	}

	/**
	 * Re-collects the lights in the scene. Call after adding, removing, or changing one.
	 */
	updateLights() {

		const { _pathTracer, scene } = this;

		const lights = getLights( scene );
		_pathTracer.setLights( lights );
		this.reset();

	}

	/**
	 * Sets the resolution the path tracer renders at. Only used when
	 * {@link WebGPUPathTracer#synchronizeRenderSize} is `false`.
	 *
	 * @param {number} x
	 * @param {number} y
	 */
	setSize( x, y ) {

		if ( this._size.x !== x || this._size.y !== y ) {

			this._size.set( x, y );

			// cameras can depend on the size
			if ( this._cameraRayFnHandle ) {

				this.updateCamera();

			} else {

				this.reset();

			}

		}

	}

	/**
	 * Discards the accumulated image and starts over. The `update*` functions call this for you.
	 */
	reset() {

		this._pathTracer.reset();
		this._denoiser?.reset();
		this._resetTime = - 1;
		this._fadeState = 0;
		this._timer.update();

		// a fresh object rather than a clear, so measurements still in flight detach
		this._lastSampleCounts = { min: 0, max: 0, avg: 0, samplesPerSecond: 0 };
		this._lastCompleteCheck = 0;
		this._wasComplete = false;

		if ( this.stableNoise ) {

			this._pathTracer.resetSeed();

		}

		// undo the adaptation's last changes, unless the app has since taken over the budget
		if ( this.adaptiveFrameBudget && this._fullFrameBudget !== null ) {

			this.frameBudget = this._fullFrameBudget;

		}

		this._fullFrameBudget = null;

	}

	// Sets the stage, reporting when each one starts
	_setStage( stage ) {

		if ( this._stage === stage ) {

			return;

		}

		this._stage = stage;
		if ( stage === STAGE_BUILDING ) {

			this.dispatchEvent( { type: 'progress', stage: 'building', progress: 0 } );

		} else if ( stage === STAGE_COMPILING ) {

			this.dispatchEvent( { type: 'progress', stage: 'compiling', progress: null } );

		} else {

			this._dispatchRenderProgress( { min: 0, max: 0, avg: 0, samplesPerSecond: 0 } );

		}

	}

	// Measures the sample counts and reports them
	_measureSamples() {

		const counts = this._lastSampleCounts;
		this.getSampleCountsAsync().then( samples => {

			// skip if the render was reset or a new scene started building meanwhile
			if ( counts === this._lastSampleCounts && this._stage === STAGE_RENDERING ) {

				// save the adaptive budget once the first pixels finish, to undo the adaptation on reset
				const { maxSamples } = this;
				if ( this.adaptiveFrameBudget && this._fullFrameBudget === null && maxSamples > 0 && samples.max >= maxSamples ) {

					this._fullFrameBudget = this.frameBudget;

				}

				this._dispatchRenderProgress( samples );

			}

		} );

	}

	_dispatchRenderProgress( samples ) {

		const { maxSamples } = this;
		const progress = maxSamples > 0 ? Math.min( samples.avg / maxSamples, 1 ) : null;
		this.dispatchEvent( { type: 'progress', stage: 'rendering', progress, samples } );

	}

	// Adapts the frame budget to the tracer's latest gpu time measurement
	_readTiming() {

		const { timing } = this._pathTracer;
		const { trackTimestamp } = this._renderer.backend;
		if ( this.adaptiveFrameBudget && ! trackTimestamp && ! this._warnedTimestamps ) {

			console.warn( 'WebGPUPathTracer: "adaptiveFrameBudget" needs timestamp queries. Create the renderer with "trackTimestamp: true" on a device that supports them.' );
			this._warnedTimestamps = true;

		}

		if ( timing.count === this._timingCount ) {

			return;

		}

		this._timingCount = timing.count;

		// a measurement from before the budget changed doesn't describe the current one
		const { frameBudget } = timing;
		if ( ! this.adaptiveFrameBudget || frameBudget !== this.frameBudget ) {

			this._frameTimeTotal = 0;
			this._frameTimeCount = 0;
			return;

		}

		this._frameTimeTotal += timing.frameTime;
		this._frameTimeCount ++;
		if ( this._frameTimeCount < BUDGET_WINDOW ) {

			return;

		}

		const { targetFrameTime } = this;
		const average = this._frameTimeTotal / this._frameTimeCount;
		this._frameTimeTotal = 0;
		this._frameTimeCount = 0;

		// leave the budget alone while it's close enough to the target
		const ratio = average / targetFrameTime;
		if ( ratio < BUDGET_CHANGE_THRESHOLD && ratio > 1 / BUDGET_CHANGE_THRESHOLD ) {

			return;

		}

		// scale the budget to land the average on the target
		const next = frameBudget * targetFrameTime / average;
		const stepped = MathUtils.clamp( next, frameBudget / BUDGET_MAX_STEP, frameBudget * BUDGET_MAX_STEP );
		this.frameBudget = Math.max( Math.round( stepped ), MIN_FRAME_BUDGET );

	}

	/**
	 * Accumulates one round of samples and presents the result to the canvas. Call once per frame.
	 */
	renderSample() {

		const renderer = this._renderer;
		const size = this._size;
		const blitQuad = this._blitQuad;
		const pathTracer = this._pathTracer;
		const lowResTarget = this._lowResTarget;
		const timer = this._timer;
		const {
			renderDelay,
			dynamicLowRes,
			synchronizeRenderSize,
			renderScale,
			adaptiveDynamicRes,
			minSamples,
			maxSamples,
		} = this;

		timer.update();

		if ( ! this._renderer._initialized ) {

			return;

		}

		if ( ! this._shadingModel.initialized ) {

			this._shadingModel.init( renderer );
			this._shadingModel.initialized = true;

		}

		let delta = 1000 * timer.getDelta();
		const firstFrame = this._resetTime === - 1;
		if ( firstFrame ) {

			this._resetTime = 0;
			delta = 0.0;

		}

		this._resetTime += delta;

		const originalTarget = renderer.getRenderTarget();
		const originalAutoClear = renderer.autoClear;

		// handle canvas-size auto synchronization
		if ( synchronizeRenderSize ) {

			renderer.getDrawingBufferSize( _resolution );
			const w = Math.floor( renderScale * _resolution.x );
			const h = Math.floor( renderScale * _resolution.y );
			this.setSize( w, h );

		}

		// check if we should be in low res mode and calculate the target size
		let { width, height } = size;
		const lowResMode = this._resetTime < renderDelay || ( firstFrame && dynamicLowRes && minSamples !== 0 );
		if ( lowResMode ) {

			// the most pixels a preview frame can render within the frame budget. Pixels past it are never
			// reached by the wavefront in a preview
			const budgetScale = Math.min( Math.sqrt( pathTracer.getPreviewPixelBudget() / ( width * height ) ), 1 );

			if ( adaptiveDynamicRes ) {

				this.lowResScale = budgetScale;

			}

			// checked every frame since the budget adapts separately
			const scale = Math.min( this.lowResScale, budgetScale );
			width = Math.max( 1, Math.floor( scale * width ) );
			height = Math.max( 1, Math.floor( scale * height ) );

		}

		// set the size if necessary
		pathTracer.getSize( _resolution );

		// copy the low res content when transitioning to the full resolution view so we can fade from
		// it, including when the preview was already full size and nothing is resized
		if ( ! lowResMode && pathTracer.lowResMode && dynamicLowRes ) {

			lowResTarget.setSize( _resolution.x, _resolution.y );
			renderer.copyTextureToTexture( pathTracer.outputTarget, lowResTarget );

		}

		if ( _resolution.x !== width || _resolution.y !== height ) {

			pathTracer.setSize( width, height );

		}

		// update the samples, stopping once every pixel has reached "maxSamples"
		const samplesComplete = maxSamples > 0 && this._lastSampleCounts.min >= maxSamples;
		if ( ! this.pause && ! samplesComplete && this._stage > STAGE_BUILDING && ( ! lowResMode || ( lowResMode && dynamicLowRes ) ) ) {

			pathTracer.lowResMode = lowResMode;
			pathTracer.asyncCompile = this.asyncCompile;
			pathTracer.update();
			this._readTiming();
			this._setStage( pathTracer.compiling ? STAGE_COMPILING : STAGE_RENDERING );

		}

		// nothing renders while the next scene's BVHs build or the kernels compile, so restart the preview timer and
		// keep the last frame
		// TODO: decide what to display meanwhile - the last frame goes stale when the camera moves, and a
		// rasterized preview compiles its own materials
		if ( this._stage < STAGE_RENDERING ) {

			this._resetTime = - 1;
			return;

		}

		const denoiser = this._denoiser;
		const upscaler = this._upscaler;

		// the denoiser runs once the render stops, so an uncapped render never denoises
		// TODO: this only needs to know whether the render stopped, but measures the per pixel
		// counts every frame. A count of the camera rays dispatched would answer it in one value
		const awaitingDenoise = Boolean( denoiser ) && ! denoiser.complete && ! denoiser.running && maxSamples > 0;

		// Gate on the average pixel. Measuring is expensive so it stops once faded in, and
		// the check reads the last measurement rather than waiting on this one.
		if ( ! lowResMode ) {

			// the counts can't change once every pixel has finished, so measuring stops
			if ( ! samplesComplete && this._fadeState < 1 && minSamples > 0 ) {

				this._measureSamples();

			} else if ( ! samplesComplete && this._resetTime - this._lastCompleteCheck >= COMPLETE_CHECK_INTERVAL ) {

				// the readback stalls the gpu pipeline, so the render only measures a few times a second.
				// The "progress" and "complete" events and the denoiser key off it
				this._lastCompleteCheck = this._resetTime;
				this._measureSamples();

			}

			if ( this._lastSampleCounts.avg >= minSamples ) {

				this._fadeState += delta / this.fadeDuration;
				this._fadeState = Math.min( 1.0, this._fadeState ) || 1.0;

			}

		}


		// render the content to the canvas
		const opacity = ( lowResMode && dynamicLowRes ? 1.0 : this._fadeState );

		// the low res preview is replaced moments later, so it is neither denoised nor upscaled
		let texture = pathTracer.outputTarget;
		if ( denoiser && ! lowResMode ) {

			// "min" so every pixel has stopped, not just the average
			if ( awaitingDenoise && this._lastSampleCounts.min >= maxSamples ) {

				denoiser.update( pathTracer.outputTarget, pathTracer.auxTarget );

			}

			texture = denoiser.texture ?? texture;

		}

		// the upscale and the draw only serve the display
		if ( this.renderToCanvas ) {

			if ( upscaler && ! lowResMode ) {

				texture = upscaler.upscale( texture, this.camera );

				// the pass above binds its own targets
				renderer.setRenderTarget( originalTarget );

			}

			renderer.autoClear = dynamicLowRes ? true : opacity === 1.0;
			blitQuad.material.transition = dynamicLowRes ? opacity : 1.0;
			blitQuad.material.opacity = dynamicLowRes ? 1.0 : opacity;
			blitQuad.material.fromTexture = lowResTarget;
			blitQuad.material.texture = texture;
			blitQuad.render( renderer );

		}

		// reset the renderer
		renderer.autoClear = originalAutoClear;
		renderer.setRenderTarget( originalTarget );

		// fires once the render, and the denoiser if one is attached, has finished and the result is drawn
		const complete = this.complete;
		if ( complete && ! this._wasComplete ) {

			this.dispatchEvent( { type: 'complete' } );

		}

		this._wasComplete = complete;

	}

	/**
	 * Draws a heatmap of how many BVH bounding boxes each camera ray intersects, for diagnosing
	 * box overlap and traversal cost. Hotter pixels traverse more nodes.
	 *
	 * @param {Object} [options]
	 * @param {boolean} [options.displayTLAS=true] - Count the top level object bounding boxes.
	 * @param {boolean} [options.displayBLAS=true] - Count the per object geometry bounding boxes.
	 * @param {boolean} [options.stopAtSurface=false] - Only count boxes in front of the nearest
	 *   hit, so occluded boxes do not contribute. Culling and material transparency are honored.
	 * @param {number} [options.saturationCount=64] - Node count that saturates to full heat.
	 */
	renderDebugBounds( options = {} ) {

		const {
			displayTLAS = true,
			displayBLAS = true,
			stopAtSurface = false,
			saturationCount = 64,
		} = options;

		const renderer = this._renderer;
		const camera = this.camera;

		if ( ! renderer._initialized ) {

			return;

		}

		camera.updateMatrixWorld();

		// (re)build the quad if it hasn't been built or the bvh data or shading model has changed
		if ( this._debugBoundsQuad === undefined || this._debugBoundsData !== this._bvhData || this._debugBoundsShadingModel !== this._shadingModel ) {

			this._buildDebugBoundsQuad();

		}

		const uniforms = this._debugBoundsUniforms;
		uniforms.cameraToModelMatrix.value.copy( camera.matrixWorld );
		uniforms.inverseProjectionMatrix.value.copy( camera.projectionMatrixInverse );
		uniforms.displayTLAS.value = displayTLAS ? 1 : 0;
		uniforms.displayBLAS.value = displayBLAS ? 1 : 0;
		uniforms.stopAtSurface.value = stopAtSurface ? 1 : 0;
		uniforms.saturationCount.value = saturationCount;

		const originalTarget = renderer.getRenderTarget();
		const originalAutoClear = renderer.autoClear;
		const originalToneMapping = renderer.toneMapping;

		renderer.setRenderTarget( null );
		renderer.autoClear = true;
		renderer.toneMapping = NoToneMapping;

		this._debugBoundsQuad.render( renderer );

		renderer.setRenderTarget( originalTarget );
		renderer.autoClear = originalAutoClear;
		renderer.toneMapping = originalToneMapping;

	}

	_buildDebugBoundsQuad() {

		const { _bvhData: bvhData, _shadingModel: shadingModel } = this;
		const debugBounds = getDebugBoundsFunction( bvhData, shadingModel );

		const material = new MeshBasicNodeMaterial();
		material.colorNode = debugBounds( varying( uv() ) );

		if ( this._debugBoundsQuad === undefined ) {

			this._debugBoundsQuad = new FullScreenQuad( material );

		} else {

			this._debugBoundsQuad.material.dispose();
			this._debugBoundsQuad.material = material;

		}

		this._debugBoundsUniforms = debugBounds.uniforms;
		this._debugBoundsData = bvhData;
		this._debugBoundsShadingModel = shadingModel;

	}

	/**
	 * Draws one layer of the texture atlas to the canvas, for debugging texture packing.
	 *
	 * @param {number} [layer=0]
	 */
	renderTextureAtlas( layer = 0 ) {

		const renderer = this._renderer;

		if ( ! this._atlasDebugQuad ) {

			this._atlasDebugQuad = new FullScreenQuad( new AtlasDebugMaterial() );

		}

		const quad = this._atlasDebugQuad;
		quad.material.texture = this.textureAtlas.texture;
		quad.material.layer = layer;
		renderer.setRenderTarget( null );
		quad.render( renderer );

	}

	/**
	 * Draws a heatmap of the per pixel sample counts, for spotting pixels that converge slowly.
	 * @note Measures on every call and draws with the previous result, since the readback lands a
	 *   frame later.
	 */
	// TODO: bind the counters buffer in the shader instead to avoid the readback.
	renderSampleDensity() {

		const renderer = this._renderer;

		if ( ! renderer._initialized ) {

			return;

		}

		this.getSampleCountsAsync();

		if ( ! this._sampleDensityQuad ) {

			this._sampleDensityQuad = new FullScreenQuad( new SampleDensityMaterial() );

		}

		const originalToneMapping = renderer.toneMapping;
		renderer.toneMapping = NoToneMapping;

		const quad = this._sampleDensityQuad;
		quad.material.texture = this._pathTracer.sampleCountTarget;
		quad.material.minCount = this._lastSampleCounts.min;
		quad.material.maxCount = this._lastSampleCounts.max;
		renderer.setRenderTarget( null );
		quad.render( renderer );

		renderer.toneMapping = originalToneMapping;

	}

	/**
	 * Draws the albedo or normal auxiliary buffer accumulated for the denoiser, for checking what
	 * it is given. Nothing is drawn until a denoiser that uses them is attached.
	 *
	 * @param {'albedo'|'normal'} [buffer='albedo']
	 */
	renderAuxBuffer( buffer = 'albedo' ) {

		const renderer = this._renderer;
		const pathTracer = this._pathTracer;

		if ( ! renderer._initialized || ! pathTracer.auxTarget ) {

			return;

		}

		if ( ! this._auxDebugQuad ) {

			this._auxDebugQuad = new FullScreenQuad( new AuxDebugMaterial() );

		}

		const originalToneMapping = renderer.toneMapping;
		renderer.toneMapping = NoToneMapping;

		const quad = this._auxDebugQuad;
		quad.material.texture = pathTracer.auxTarget;
		quad.material.showNormal = buffer === 'normal';
		renderer.setRenderTarget( null );
		quad.render( renderer );

		renderer.toneMapping = originalToneMapping;

	}

	/**
	 * Frees every GPU resource held by the tracer, including any attached denoiser and upscaler.
	 */
	dispose() {

		this._pathTracer.dispose();
		this._denoiser?.dispose();
		this._upscaler?.dispose();
		this._bvhData.dispose();
		this._shadingModel.dispose();
		this._environmentCache.dispose();
		this._backgroundCache.dispose();
		this._lowResTarget.dispose();

		// FullScreenQuad.dispose only disposes the shared geometry, not the material
		this._blitQuad.dispose();
		this._blitQuad.material.dispose();
		this._atlasDebugQuad?.dispose();
		this._atlasDebugQuad?.material.dispose();
		this._sampleDensityQuad?.dispose();
		this._sampleDensityQuad?.material.dispose();
		this._auxDebugQuad?.dispose();
		this._auxDebugQuad?.material.dispose();

		if ( this._debugBoundsQuad !== undefined ) {

			this._debugBoundsQuad.dispose();
			this._debugBoundsQuad.material.dispose();

		}

	}

	/**
	 * Milliseconds elapsed since the last reset.
	 * @returns {number}
	 */
	// TODO: this is not completely accurate if the user has not called "renderSample" continuously
	getRenderTime() {

		return this._resetTime;

	}

}

import { Matrix4, StorageBufferAttribute, Vector2 } from 'three/webgpu';
import { PopulatePixelIndicesKernel } from './compute/wavefront/PopulatePixelIndicesKernel.js';
import { LogicKernel } from './compute/wavefront/LogicKernel.js';
import { MaterialKernel } from './compute/wavefront/MaterialKernel.js';
import { TraceRayKernel } from './compute/wavefront/TraceRayKernel.js';
import { TraceShadowRayKernel } from './compute/wavefront/TraceShadowRayKernel.js';
import { MediumKernel } from './compute/wavefront/MediumKernel.js';
import { QueueMediumWalksKernel } from './compute/wavefront/QueueMediumWalksKernel.js';
import { CameraRayKernel } from './compute/wavefront/CameraRayKernel.js';
import { CameraMediumKernel } from './compute/wavefront/CameraMediumKernel.js';
import { QueueLengthToDispatchKernel } from './compute/wavefront/QueueLengthToDispatchKernel.js';
import { ResetSlotsKernel } from './compute/wavefront/ResetSlotsKernel.js';
import { ZeroOutBufferKernel } from './compute/ZeroOutBufferKernel.js';
import { CopyBufferKernel } from './compute/CopyBufferKernel.js';
import { EquirectHdrInfoNode } from './EquirectHdrInfoNode.js';
import { EquirectBackgroundInfo } from './EquirectBackgroundInfo.js';
import { LightsInfoNode } from './LightsInfoNode.js';
import {
	rayDataStruct, traceQueuedRayStruct, intersectionResultStruct, shadowTraceResultStruct,
	RAY_QUEUE_LENGTH, SHADOW_RAY_QUEUE_LENGTH, QUEUE_COUNTER_COUNT, PIXEL_QUEUE_HEADER,
	MEDIUM_QUEUE_LENGTH, MEDIUM_QUEUE_HEADER,
} from './compute/wavefront/structs.js';
import { PathTracerBackend } from './PathTracerBackend.js';
import { FILTER_GLOSSY_DISABLED } from './nodes/material.wgsl.js';
import {
	PrimeSampleCountersKernel,
	TallySampleCountsKernel,
	SAMPLE_COUNTER_LENGTH,
	SAMPLE_COUNTER_MAX,
	SAMPLE_COUNTER_MIN,
	SAMPLE_COUNTER_PIXEL_COUNT,
	SAMPLE_COUNTER_TOTAL_HI,
	SAMPLE_COUNTER_TOTAL_LO,
	U32_RANGE,
} from './compute/TallySampleCountsKernel.js';

// set the buffers to the max possible size supported by default (128MB)
// TODO: this can be increased based on platform.
const MAX_BUFFER_SIZE = 134217728;

// the persistent path-slot pool is sized off the ray data struct; every other per-slot buffer
// ( queues, intersections ) is sized to the same count so a full pool can never overflow them
const MAX_RAY_DATA_COUNT = Math.floor( MAX_BUFFER_SIZE / ( rayDataStruct.getLength() * 4 ) );

const LOW_RES_ITERATIONS = 5;

export class WaveFrontPathTracer extends PathTracerBackend {

	constructor( renderer ) {

		super( renderer );

		// options
		this.globalSeed = 0;

		// scatter events a medium walk takes per pass
		this.mediumStepsPerPass = 16;

		this.envInfo = new EquirectHdrInfoNode();
		this.backgroundInfo = new EquirectBackgroundInfo();
		this.lightsInfo = new LightsInfoNode( this.envInfo );

		// The path slot pool, sized to the frame budget and resized in the render loop as the budget
		// changes. Every per-slot buffer is allocated to the same count so a full pool can never
		// overflow them.
		this.rayCount = 0;

		// persistent per-path state, one slot per in-flight path
		this.rayDataStorage = null;

		// append-only trace queues, with their lengths in the counters buffer
		this.rayQueue = null;
		this.shadowRayQueue = null;
		this.queueCounters = new StorageBufferAttribute( new Uint32Array( QUEUE_COUNTER_COUNT ), 1 );
		this.queueCounters.name = 'Queue Counters';

		// per-queue-slot trace results, indexed by the ray's position in its queue. The ray results also
		// hold the hits of medium walks, filled from the back
		this.rayIntersectionsStorage = null;
		this.shadowRayIntersectionsStorage = null;

		// the slots walking a medium this pass
		this.mediumQueue = null;

		// pixel indices waiting for a free path slot, sized to the resolution
		this.pixelQueue = null;

		// reduction target for the per pixel sample counts, read back asynchronously
		this.sampleCountersStorage = new StorageBufferAttribute( new Uint32Array( SAMPLE_COUNTER_LENGTH ), SAMPLE_COUNTER_LENGTH );
		this.sampleCountersStorage.name = 'Sample Counters';
		this._samplesPromise = null;

		// kernels
		this.populatePixelIndicesKernel = new PopulatePixelIndicesKernel().setWorkgroupSize( 8, 8, 1 );
		this.logicKernel = new LogicKernel().setWorkgroupSize( 64, 1, 1 );
		this.materialKernel = new MaterialKernel().setWorkgroupSize( 64, 1, 1 );
		this.traceRayKernel = new TraceRayKernel().setWorkgroupSize( 64, 1, 1 );
		this.traceShadowRayKernel = new TraceShadowRayKernel().setWorkgroupSize( 64, 1, 1 );
		this.mediumKernel = new MediumKernel().setWorkgroupSize( 64, 1, 1 );
		this.queueMediumWalksKernel = new QueueMediumWalksKernel().setWorkgroupSize( 64, 1, 1 );
		this.cameraRayKernel = new CameraRayKernel().setWorkgroupSize( 64, 1, 1 );
		this.cameraMediumKernel = new CameraMediumKernel().setWorkgroupSize( 64, 1, 1 );
		this.rayDispatchConverter = new QueueLengthToDispatchKernel( RAY_QUEUE_LENGTH ).setWorkgroupSize( 1, 1, 1 );
		this.shadowDispatchConverter = new QueueLengthToDispatchKernel( SHADOW_RAY_QUEUE_LENGTH ).setWorkgroupSize( 1, 1, 1 );
		this.mediumDispatchConverter = new QueueLengthToDispatchKernel( MEDIUM_QUEUE_LENGTH ).setWorkgroupSize( 1, 1, 1 );
		this.primeSampleCountersKernel = new PrimeSampleCountersKernel().setWorkgroupSize( 1, 1, 1 );
		this.tallySampleCountsKernel = new TallySampleCountsKernel().setWorkgroupSize( 8, 8, 1 );

		// pool resizing: carry live slots into a reallocated pool and idle the rest
		this.resetSlotsKernel = new ResetSlotsKernel().setWorkgroupSize( 64, 1, 1 );
		this.copyRayDataKernel = new CopyBufferKernel( rayDataStruct ).setWorkgroupSize( 64, 1, 1 );

		// bind the shared env / lights providers so the kernels' proxies resolve even before they're set
		this.logicKernel.envInfo = this.envInfo;
		this.logicKernel.backgroundInfo = this.backgroundInfo;
		this.logicKernel.lightsInfo = this.lightsInfo;

		// clear kernels
		this.zeroDispatchKernel = new ZeroOutBufferKernel().setWorkgroupSize( 1, 1, 1 );

	}

	resetSeed() {

		this.globalSeed = 0;

	}

	reset() {

		super.reset();
		this.globalSeed ++;
		this._samplesPromise = null;

	}

	setBVHData( bvhData ) {

		this.materialKernel.context.bvhData = bvhData;
		this.traceRayKernel.context.bvhData = bvhData;
		this.traceShadowRayKernel.context.bvhData = bvhData;
		this.mediumKernel.context.bvhData = bvhData;
		this.cameraRayKernel.context.bvhData = bvhData;
		this.cameraMediumKernel.context.bvhData = bvhData;
		this.rebuild();

	}

	rebuild() {

		super.rebuild();

		// recompile the kernels that bake in the scene, camera, random and shading model functions
		this.logicKernel.needsUpdate = true;
		this.materialKernel.needsUpdate = true;
		this.traceRayKernel.needsUpdate = true;
		this.traceShadowRayKernel.needsUpdate = true;
		this.mediumKernel.needsUpdate = true;
		this.cameraRayKernel.needsUpdate = true;
		this.cameraMediumKernel.needsUpdate = true;
		this.reset();

	}

	setRandom( random ) {

		this.logicKernel.context.random = random;
		this.materialKernel.context.random = random;
		this.cameraRayKernel.context.random = random;
		this.traceRayKernel.context.random = random;
		this.traceShadowRayKernel.context.random = random;
		this.mediumKernel.context.random = random;
		this.rebuild();

	}

	setShadingModel( shadingModel ) {

		// the ray traversal reads the shading model's materials
		this.materialKernel.context.shadingModel = shadingModel;
		this.traceRayKernel.context.shadingModel = shadingModel;
		this.traceShadowRayKernel.context.shadingModel = shadingModel;
		this.mediumKernel.context.shadingModel = shadingModel;
		this.cameraMediumKernel.context.shadingModel = shadingModel;
		this.rebuild();

	}

	setFilterGlossy( value ) {

		// the kernel takes the inverted threshold, mirroring Cycles
		this.materialKernel.filterGlossy = value === 0 ? FILTER_GLOSSY_DISABLED : 1 / value;
		this.reset();

	}

	setClamping( direct, indirect ) {

		this.logicKernel.clampDirect = direct;
		this.logicKernel.clampIndirect = indirect;
		this.reset();

	}

	setTransmissiveBackground( value ) {

		this.logicKernel.transmissiveBackground = value;
		this.reset();

	}

	setEnvironment( envMap ) {

		this.envInfo.updateFrom( envMap );

	}

	setLights( lights ) {

		if ( this.lightsInfo.updateFrom( this.renderer, lights ) ) {

			this.rebuild();

		}

		this.reset();

	}

	setEnvironmentParams( envMapIntensity, envMapRotation ) {

		const { envInfo } = this;
		const rotationMatrix = new Matrix4().makeRotationFromEuler( envMapRotation ).invert();
		envInfo.rotationNode.value.setFromMatrix4( rotationMatrix );
		envInfo.intensityNode.value = envMapIntensity;

	}

	setMultipleImportanceSampling( enabled ) {

		this.logicKernel.misEnabled = enabled ? 1 : 0;
		this.reset();

	}

	setBackground( background ) {

		const { backgroundInfo } = this;
		backgroundInfo.dispose();
		backgroundInfo.map = background;

	}

	setBackgroundParams(
		backgroundIntensity,
		backgroundRotation,
		backgroundBlurriness,
	) {

		const { backgroundInfo } = this;
		const rotationMatrix = new Matrix4().makeRotationFromEuler( backgroundRotation ).invert();
		backgroundInfo.rotationNode.value.copy( rotationMatrix );
		backgroundInfo.intensity = backgroundIntensity;
		backgroundInfo.blur = backgroundBlurriness;

	}

	dispose() {

		super.dispose();

		this.envInfo.dispose();
		this.lightsInfo.dispose();

		this.rayDataStorage?.dispose();
		this.rayQueue?.dispose();
		this.shadowRayQueue?.dispose();
		this.queueCounters.dispose();
		this.rayIntersectionsStorage?.dispose();
		this.shadowRayIntersectionsStorage?.dispose();
		this.mediumQueue?.dispose();
		this.sampleCountersStorage.dispose();
		this.pixelQueue?.dispose();

		// TODO: the dispatch converters own their indirect dispatch buffers, they should dispose of them themselves
		this.rayDispatchConverter.outputDispatch.dispose();
		this.shadowDispatchConverter.outputDispatch.dispose();
		this.mediumDispatchConverter.outputDispatch.dispose();

		this.populatePixelIndicesKernel.dispose();
		this.logicKernel.dispose();
		this.materialKernel.dispose();
		this.traceRayKernel.dispose();
		this.traceShadowRayKernel.dispose();
		this.mediumKernel.dispose();
		this.queueMediumWalksKernel.dispose();
		this.cameraRayKernel.dispose();
		this.cameraMediumKernel.dispose();
		this.rayDispatchConverter.dispose();
		this.shadowDispatchConverter.dispose();
		this.mediumDispatchConverter.dispose();
		this.primeSampleCountersKernel.dispose();
		this.tallySampleCountsKernel.dispose();
		this.resetSlotsKernel.dispose();
		this.copyRayDataKernel.dispose();
		this.zeroDispatchKernel.dispose();

	}

	// The queue holds every pixel not owned by a slot. It is sized to the full pixel count so slots
	// retired by a shrink can always return theirs.
	_updatePixelQueue( width, height ) {

		const size = PIXEL_QUEUE_HEADER + Math.max( width * height, 1 );
		if ( ! this.pixelQueue || this.pixelQueue.array.length < size ) {

			this.pixelQueue?.dispose();
			this.pixelQueue = new StorageBufferAttribute( new Float32Array( size ), size );
			this.pixelQueue.name = 'Pixel Queue';

			// three rebinds a swapped buffer, so the kernels keep their compiled pipelines
			this.cameraRayKernel.pixelQueue = this.pixelQueue;
			this.populatePixelIndicesKernel.pixelQueue = this.pixelQueue;
			this.resetSlotsKernel.pixelQueue = this.pixelQueue;

		}

	}

	// Reallocates the per slot buffers to "count" slots. Slots that survive carry their ray data
	// over, dropped slots return their pixel to the queue, and added slots take one from it. Only
	// the slots in use, up to the pixel count, hold pixels. The trace queues and results only live
	// within a frame, so they start empty.
	_resizePool( count, pixelCount ) {

		const { resetSlotsKernel, copyRayDataKernel } = this;
		const previousCount = this.rayCount;
		const previousActive = Math.min( previousCount, pixelCount );
		const active = Math.min( count, pixelCount );

		resetSlotsKernel.pixelQueue = this.pixelQueue;
		if ( active < previousActive ) {

			resetSlotsKernel.rayDataStorage = this.rayDataStorage;
			resetSlotsKernel.start = active;
			resetSlotsKernel.end = previousActive;
			resetSlotsKernel.addingSlots = false;
			this.dispatch( resetSlotsKernel, resetSlotsKernel.getDispatchSize( previousActive - active, 1, 1 ) );

		}

		const rayDataStorage = new StorageBufferAttribute( count, rayDataStruct.getLength() );
		rayDataStorage.name = 'Ray Data';

		const rayQueue = new StorageBufferAttribute( count, traceQueuedRayStruct.getLength() );
		rayQueue.name = 'Ray Queue';

		const shadowRayQueue = new StorageBufferAttribute( count, traceQueuedRayStruct.getLength() );
		shadowRayQueue.name = 'Shadow Ray Queue';

		// Traced rays fill the results from the front at their queue index, and MediumKernel fills them from the
		// back with the hits of medium walks. In a round each path slot either queues one ray or walks a medium,
		// never both, so the two ranges together never exceed the slot count and can't overlap
		const rayIntersectionsStorage = new StorageBufferAttribute( count, intersectionResultStruct.getLength() );
		rayIntersectionsStorage.name = 'Ray Intersections';

		const shadowRayIntersectionsStorage = new StorageBufferAttribute( count, shadowTraceResultStruct.getLength() );
		shadowRayIntersectionsStorage.name = 'Shadow Ray Intersections';

		const mediumQueueSize = MEDIUM_QUEUE_HEADER + count;
		const mediumQueue = new StorageBufferAttribute( new Uint32Array( mediumQueueSize ), mediumQueueSize );
		mediumQueue.name = 'Medium Queue';

		const copyCount = Math.min( count, previousCount );
		if ( copyCount > 0 ) {

			copyRayDataKernel.source = this.rayDataStorage;
			copyRayDataKernel.target = rayDataStorage;
			copyRayDataKernel.count = copyCount;
			this.dispatch( copyRayDataKernel, copyRayDataKernel.getDispatchSize( copyCount, 1, 1 ) );

		}

		this.rayDataStorage?.dispose();
		this.rayQueue?.dispose();
		this.shadowRayQueue?.dispose();
		this.rayIntersectionsStorage?.dispose();
		this.shadowRayIntersectionsStorage?.dispose();
		this.mediumQueue?.dispose();

		this.rayDataStorage = rayDataStorage;
		this.rayQueue = rayQueue;
		this.shadowRayQueue = shadowRayQueue;
		this.rayIntersectionsStorage = rayIntersectionsStorage;
		this.shadowRayIntersectionsStorage = shadowRayIntersectionsStorage;
		this.mediumQueue = mediumQueue;
		this.rayCount = count;

		if ( active > previousActive ) {

			resetSlotsKernel.rayDataStorage = rayDataStorage;
			resetSlotsKernel.start = previousActive;
			resetSlotsKernel.end = active;
			resetSlotsKernel.addingSlots = true;
			this.dispatch( resetSlotsKernel, resetSlotsKernel.getDispatchSize( active - previousActive, 1, 1 ) );

		}

	}

	// The slot count the current budget asks for, capped by the pool limit
	_getRequestedSlotCount() {

		return Math.min( MAX_RAY_DATA_COUNT, Math.max( 1, Math.floor( this.frameBudget ) ) );

	}

	// a preview runs at least this many iterations so its samples finish within the frame
	_getPreviewIterations() {

		return Math.max( 1, Math.min( this.maxBounces, LOW_RES_ITERATIONS ) );

	}

	// a preview steps every path several times, so it covers that many fewer pixels than the budget
	getPreviewPixelBudget() {

		return Math.min( this.frameBudget / this._getPreviewIterations(), MAX_RAY_DATA_COUNT );

	}

	// Resizes the pool when the budget changes. Paths in flight past a smaller budget are dropped.
	_applyBudget( pixelCount ) {

		const requested = this._getRequestedSlotCount();
		if ( requested !== this.rayCount ) {

			this._resizePool( requested, pixelCount );

		}

	}

	*createRenderTask() {

		const {
			renderer,
			maxTransparentBounces,

			logicKernel,
			materialKernel,
			traceRayKernel,
			traceShadowRayKernel,
			mediumKernel,
			queueMediumWalksKernel,
			cameraRayKernel,
			cameraMediumKernel,
			rayDispatchConverter,
			shadowDispatchConverter,
			mediumDispatchConverter,
			zeroDispatchKernel,
			populatePixelIndicesKernel,
			resetSlotsKernel,
			copyRayDataKernel,
		} = this;

		// compile the kernels before their first dispatch, including the pool resize's below
		yield* this.compileKernels( [
			logicKernel,
			materialKernel,
			traceRayKernel,
			traceShadowRayKernel,
			mediumKernel,
			queueMediumWalksKernel,
			cameraRayKernel,
			cameraMediumKernel,
			rayDispatchConverter,
			shadowDispatchConverter,
			mediumDispatchConverter,
			zeroDispatchKernel,
			populatePixelIndicesKernel,
			resetSlotsKernel,
			copyRayDataKernel,
		] );

		// a resize resets, recreating this task, so the dimensions and pixel queue hold for its
		// lifetime. The slot pool starts tight, at the budget, and is resized in the loop below.
		const targetDimensions = new Vector2();
		this.getSize( targetDimensions );

		// referenced via "this" since the buffers may be replaced here and in the loop
		this._updatePixelQueue( targetDimensions.x, targetDimensions.y );

		// the populate pass below overwrites whatever the resize carried over
		const pixelCount = targetDimensions.x * targetDimensions.y;
		this._applyBudget( pixelCount );

		// reset the trace queues — only their lengths need zeroing
		zeroDispatchKernel.target = this.queueCounters;
		this.dispatch( zeroDispatchKernel, [ QUEUE_COUNTER_COUNT ] );

		// assign every path slot in use a pixel and park the overflow pixels in the pixel queue
		populatePixelIndicesKernel.rayDataStorage = this.rayDataStorage;
		populatePixelIndicesKernel.pixelQueue = this.pixelQueue;
		populatePixelIndicesKernel.frameBudget = Math.min( this.rayCount, pixelCount );
		populatePixelIndicesKernel.targetDimensions.copy( targetDimensions );
		this.dispatch( populatePixelIndicesKernel, populatePixelIndicesKernel.getDispatchSize( targetDimensions.x, targetDimensions.y, 1 ) );

		// the sample count indexes each pixel's sequence, and the global seed gives each render its own
		logicKernel.globalSeed = this.globalSeed;
		materialKernel.globalSeed = this.globalSeed;
		cameraRayKernel.globalSeed = this.globalSeed;
		traceRayKernel.globalSeed = this.globalSeed;
		traceShadowRayKernel.globalSeed = this.globalSeed;
		mediumKernel.globalSeed = this.globalSeed;

		while ( true ) {

			// the iterations that spend the budget over the slots in use
			const activeSlots = Math.min( this._getRequestedSlotCount(), pixelCount );
			const minIterations = this.lowResMode ? this._getPreviewIterations() : 1;
			const iter = Math.max( minIterations, Math.round( this.frameBudget / activeSlots ) );

			for ( let i = 0; i < iter; i ++ ) {

				// Swap targets to support devices without <rgba32float, read_write> textures
				// Copy latest data to a new outputTarget to keep the appearance
				// TODO: this full resolution copy runs every frame - remove it by writing terminated
				// samples to both targets or gating the swap on devices that support read_write
				renderer.copyTextureToTexture( this.outputTarget, this.prevOutputTarget );
				[ this.outputTarget, this.prevOutputTarget ] = [ this.prevOutputTarget, this.outputTarget ];
				logicKernel.prevOutputTarget = this.prevOutputTarget;
				logicKernel.outputTarget = this.outputTarget;
				logicKernel.sampleCountTarget = this.sampleCountTarget;
				logicKernel.auxTarget = this.auxTarget ?? this._auxPlaceholder;
				logicKernel.accumulateAux = this.auxTarget ? 1 : 0;

				// Step 1: resolve last frame's trace results — accumulate NEE / emission / env, terminate
				// finished paths into the output, and pick the next NEE light for each live path
				logicKernel.rayDataStorage = this.rayDataStorage;
				logicKernel.rayIntersectionsStorage = this.rayIntersectionsStorage;
				logicKernel.shadowRayIntersectionsStorage = this.shadowRayIntersectionsStorage;
				logicKernel.maxBounces = this.maxBounces;
				logicKernel.rayCount = Math.min( this.rayCount, pixelCount );
				this.dispatch( logicKernel, logicKernel.getDispatchSize( logicKernel.rayCount, 1, 1 ) );

				// the trace results are consumed, so only the slot state has to survive a resize
				this._applyBudget( pixelCount );

				const {
					rayDataStorage,
					rayQueue,
					shadowRayQueue,
					queueCounters,
					rayIntersectionsStorage,
					shadowRayIntersectionsStorage,
					mediumQueue,
				} = this;

				// slots past the pixel count never run
				const rayCount = Math.min( this.rayCount, pixelCount );

				// Step 2: reset the trace queues for this frame's population
				zeroDispatchKernel.target = queueCounters;
				this.dispatch( zeroDispatchKernel, [ QUEUE_COUNTER_COUNT ] );

				zeroDispatchKernel.target = mediumQueue;
				this.dispatch( zeroDispatchKernel, [ MEDIUM_QUEUE_HEADER ] );

				// Step 3: evaluate materials — sample the bsdf, and enqueue this frame's bounce + shadow rays
				materialKernel.rayDataStorage = rayDataStorage;
				materialKernel.rayQueue = rayQueue;
				materialKernel.shadowRayQueue = shadowRayQueue;
				materialKernel.queueCounters = queueCounters;
				materialKernel.rayCount = rayCount;
				materialKernel.maxTransparentBounces = maxTransparentBounces;
				materialKernel.maxBounces = this.maxBounces;
				this.dispatch( materialKernel, materialKernel.getDispatchSize( rayCount, 1, 1 ) );

				// spawn camera rays for the freed slots, then find the volumes they start inside of and queue them
				// TODO: merge these two kernels, which needs one more storage buffer than the limit allows until the
				// queue counters can be dropped
				cameraRayKernel.rayDataStorage = rayDataStorage;
				cameraRayKernel.pixelQueue = this.pixelQueue;
				cameraRayKernel.sampleCountTarget = this.sampleCountTarget;
				cameraRayKernel.maxSamples = this.maxSamples;
				cameraRayKernel.rayCount = rayCount;
				cameraRayKernel.targetDimensions.copy( targetDimensions );
				this.dispatch( cameraRayKernel, cameraRayKernel.getDispatchSize( rayCount, 1, 1 ) );

				cameraMediumKernel.rayDataStorage = rayDataStorage;
				cameraMediumKernel.rayQueue = rayQueue;
				cameraMediumKernel.queueCounters = queueCounters;
				cameraMediumKernel.rayCount = rayCount;
				this.dispatch( cameraMediumKernel, cameraMediumKernel.getDispatchSize( rayCount, 1, 1 ) );

				// Step 4: convert the queue lengths into indirect dispatch sizes and trace
				rayDispatchConverter.queueCounters = queueCounters;
				this.dispatch( rayDispatchConverter, [ 1, 1, 1 ] );

				traceRayKernel.rayQueue = rayQueue;
				traceRayKernel.queueCounters = queueCounters;
				traceRayKernel.rayIntersectionsStorage = rayIntersectionsStorage;
				this.dispatch( traceRayKernel, rayDispatchConverter.outputDispatch );

				shadowDispatchConverter.queueCounters = queueCounters;
				this.dispatch( shadowDispatchConverter, [ 1, 1, 1 ] );

				traceShadowRayKernel.shadowRayQueue = shadowRayQueue;
				traceShadowRayKernel.queueCounters = queueCounters;
				traceShadowRayKernel.shadowRayIntersectionsStorage = shadowRayIntersectionsStorage;
				this.dispatch( traceShadowRayKernel, shadowDispatchConverter.outputDispatch );

				// Step 5: walk the paths inside media for a capped number of steps
				queueMediumWalksKernel.rayDataStorage = rayDataStorage;
				queueMediumWalksKernel.mediumQueue = mediumQueue;
				queueMediumWalksKernel.rayCount = rayCount;
				this.dispatch( queueMediumWalksKernel, queueMediumWalksKernel.getDispatchSize( rayCount, 1, 1 ) );

				// the medium queue's length leads it, where the converter reads it as a counter
				mediumDispatchConverter.queueCounters = mediumQueue;
				this.dispatch( mediumDispatchConverter, [ 1, 1, 1 ] );

				mediumKernel.rayDataStorage = rayDataStorage;
				mediumKernel.mediumQueue = mediumQueue;
				mediumKernel.rayIntersectionsStorage = rayIntersectionsStorage;
				mediumKernel.rayCount = rayCount;
				mediumKernel.maxSubsurfaceBounces = this.maxSubsurfaceBounces;
				mediumKernel.stepsPerPass = this.mediumStepsPerPass;
				this.dispatch( mediumKernel, mediumDispatchConverter.outputDispatch );

			}

			yield;

		}

	}

	// Reduces the per pixel sample counts and reads them back. Runs a full resolution pass, so it
	// only happens when asked for.
	getSampleCountsAsync() {

		// share the in flight measurement rather than dispatching another
		if ( this._samplesPromise === null ) {

			const promise = this._measureSampleCounts().finally( () => {

				// a reset may have started a newer measurement in the meantime
				if ( this._samplesPromise === promise ) {

					this._samplesPromise = null;

				}

			} );

			this._samplesPromise = promise;

		}

		return this._samplesPromise;

	}

	async _measureSampleCounts() {

		const {
			renderer,
			sampleCountTarget,
			sampleCountersStorage,
			primeSampleCountersKernel,
			tallySampleCountsKernel,
		} = this;

		if ( ! renderer.initialized || this.lowResMode ) {

			return { min: 0, max: 0, avg: 0 };

		}

		primeSampleCountersKernel.counters = sampleCountersStorage;
		renderer.compute( primeSampleCountersKernel.kernel, [ 1, 1, 1 ] );

		tallySampleCountsKernel.counters = sampleCountersStorage;
		tallySampleCountsKernel.sampleCountTarget = sampleCountTarget;
		renderer.compute(
			tallySampleCountsKernel.kernel,
			tallySampleCountsKernel.getDispatchSize( sampleCountTarget.width, sampleCountTarget.height ),
		);

		const buffer = await renderer.getArrayBufferAsync( sampleCountersStorage );
		const counters = new Uint32Array( buffer );
		const pixelCount = counters[ SAMPLE_COUNTER_PIXEL_COUNT ];

		// no camera ray has been dispatched yet, so there is nothing to average over
		if ( pixelCount === 0 ) {

			return { min: 0, max: 0, avg: 0 };

		}

		// the total is accumulated as a split 64 bit value to survive high sample counts
		const total = counters[ SAMPLE_COUNTER_TOTAL_HI ] * U32_RANGE + counters[ SAMPLE_COUNTER_TOTAL_LO ];

		return {
			min: counters[ SAMPLE_COUNTER_MIN ],
			max: counters[ SAMPLE_COUNTER_MAX ],
			avg: total / pixelCount,
		};

	}

}

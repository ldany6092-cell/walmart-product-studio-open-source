import { EventDispatcher, ExternalTexture } from 'three/webgpu';
import { UnpackAuxKernel } from '../compute/UnpackAuxKernel.js';
import { createAuxImageTarget } from '../compute/targets.js';

/** @import { StorageArrayTexture, Texture, WebGPURenderer } from 'three/webgpu' */
/** @import { DynamicTileSetting } from 'oidn-webgpu' */

/**
 * Fired when a pass started by `update` fails, such as the weights failing to download, with the
 * failure as the event's `error`. No other pass starts until a reset.
 * @event OIDNDenoiser#error
 */

/**
 * Fired as each tile of a pass finishes, with the fraction of the pass done as `progress`.
 * @event OIDNDenoiser#progress
 */

/**
 * Runs Open Image Denoise over a path traced image. Pass one to
 * "WebGPUPathTracer.setDenoiser", or drive it directly with "denoise".
 *
 * "initUNetFromURL" and the weights are passed in rather than imported so neither the library
 * nor the network files become a dependency.
 *
 * ```js
 * import { initUNetFromURL } from 'oidn-webgpu';
 * pathTracer.setDenoiser( new OIDNDenoiser( { initUNetFromURL, auxWeightsUrl } ) );
 * ```
 *
 * Weights come from the oidn-weights repository, where the "_small" and "_large" variants trade
 * quality against download size and per tile cost.
 */
export class OIDNDenoiser extends EventDispatcher {

	/**
	 * The denoised result, or null until the first tile has been produced.
	 *
	 * @type {ExternalTexture|null}
	 */
	get texture() {

		return this._texture;

	}

	/**
	 * Whether a pass has finished. Stays true until reset.
	 *
	 * @type {boolean}
	 */
	get complete() {

		return this._complete;

	}

	/**
	 * Whether a pass is running. The work is spread over several frames.
	 *
	 * @type {boolean}
	 */
	get running() {

		return this._running;

	}

	/**
	 * Every field below can also be assigned after construction.
	 *
	 * @param {Object} options
	 * @param {Function} options.initUNetFromURL
	 * @param {string} options.auxWeightsUrl - Weights for the guided model.
	 * @param {string} [options.colorWeightsUrl] - Weights for the color only model, needed only
	 * when `useAuxiliaryBuffers` is `false`.
	 * @param {boolean} [options.useAuxiliaryBuffers]
	 * @param {number|null} [options.maxTileSize]
	 * @param {DynamicTileSetting|null} [options.dynamicTile] - `false` pins every tile to
	 * `maxTileSize`. An object tunes the adaptive sizing.
	 */
	constructor( options = {} ) {

		super();

		const {
			initUNetFromURL,
			auxWeightsUrl,
			colorWeightsUrl,
			useAuxiliaryBuffers = true,
			maxTileSize = null,
			dynamicTile = null,
		} = options;

		if ( ! initUNetFromURL ) {

			throw new Error( 'OIDNDenoiser: "initUNetFromURL" from "oidn-webgpu" must be provided.' );

		}

		this.initUNetFromURL = initUNetFromURL;
		this.auxWeightsUrl = auxWeightsUrl;
		this.colorWeightsUrl = colorWeightsUrl;

		// `false` falls back to the color only model, which is blurrier but needs no auxiliary buffers
		this.useAuxiliaryBuffers = useAuxiliaryBuffers;

		// tiling, passed through to oidn-webgpu. Null keeps its defaults
		this.maxTileSize = maxTileSize;
		this.dynamicTile = dynamicTile;

		this.renderer = null;

		this._texture = null;
		this._running = false;
		this._complete = false;
		this._abort = null;
		this._requestId = 0;

		// set when a pass started by "update" fails, so the render loop doesn't start another until a reset
		this._failed = false;
		this._unets = { aux: null, color: null };

		this._resultPipeline = null;
		this._rawTexture = null;

		// the albedo and normal unpacked from the path tracer's auxiliary target for a pass
		this._unpackAuxKernel = new UnpackAuxKernel().setWorkgroupSize( 8, 8, 1 );
		this._albedoTarget = createAuxImageTarget( 'Denoiser Albedo' );
		this._normalTarget = createAuxImageTarget( 'Denoiser Normal' );

	}

	/**
	 * @param {WebGPURenderer} renderer
	 */
	init( renderer ) {

		this.renderer = renderer;

	}

	/**
	 * Unpacks the auxiliary buffers the path tracer accumulated and starts a pass. Safe to call
	 * every frame.
	 *
	 * @param {Texture} target - The path traced result, in linear HDR.
	 * @param {StorageArrayTexture|null} aux - The packed auxiliary buffers, see "auxiliary.wgsl.js".
	 * @returns {Texture|null}
	 */
	update( target, aux = null ) {

		if ( this._complete || this._running || this._failed ) {

			return this._texture;

		}

		// TODO: denoise the alpha for transparent backgrounds. oidn-webgpu's "denoiseAlpha" runs as a
		// second pass, but its "_updatePasses" doesn't rebuild its shaders when the option changes
		let albedo = null;
		let normal = null;
		if ( this.useAuxiliaryBuffers && aux ) {

			this._unpackAux( aux );
			albedo = this._albedoTarget;
			normal = this._normalTarget;

		}

		// a failure, such as the weights failing to download, is reported once rather than every frame
		this.denoise( target, albedo, normal ).catch( error => {

			this._failed = true;
			this.dispatchEvent( { type: 'error', error } );

		} );

		return this._texture;

	}

	/**
	 * Runs a pass unless one is already running or finished. The optional albedo and normal
	 * buffers guide the filter and select the guided model. Both hold [0,1] values, with normals
	 * mapped so a flat normal is (0.5, 0.5, 1).
	 *
	 * @param {Texture} color - The path traced result, in linear HDR.
	 * @param {Texture|null} albedo
	 * @param {Texture|null} normal
	 */
	async denoise( color, albedo = null, normal = null ) {

		if ( this._complete || this._running ) {

			return;

		}

		this._running = true;

		const useAux = Boolean( albedo && normal );
		const requestId = ++ this._requestId;

		let unet;
		try {

			unet = await this._initUNet( useAux );

		} catch ( error ) {

			// leaving "running" set would stall every later pass
			this._running = false;
			throw error;

		}

		// bail if a reset or a newer call took over while the weights downloaded
		if ( requestId !== this._requestId || ! this._running ) {

			return;

		}

		// three only holds a WebGPU texture for a three texture once it has been initialized
		const { renderer } = this;
		const backend = renderer.backend;
		renderer.initTexture( color );

		const { width, height } = color;
		const inputs = {
			color: { data: backend.get( color ).texture, width, height },

			// pace the tiles to display frames so the path tracer keeps rendering between them
			scheduling: 'animation-frame',

			// the output is seeded with the raw color, so copying per tile shows a progressive wipe
			progress: ( output, tileData, tile, tileIndex, tileCount ) => {

				this._copyOutputToTexture( output, width, height );
				this.dispatchEvent( { type: 'progress', progress: ( tileIndex + 1 ) / tileCount } );

			},
			done: output => {

				this._running = false;
				this._complete = true;
				this._abort = null;
				this._disposeAuxImages();

			},
		};

		// the guided model needs both buffers, and the color only model must not be given them
		if ( useAux ) {

			renderer.initTexture( albedo );
			renderer.initTexture( normal );
			inputs.albedo = { data: backend.get( albedo ).texture, width, height };
			inputs.normal = { data: backend.get( normal ).texture, width, height };

		}

		this._abort = unet.tileExecute( inputs );

	}

	/**
	 * Drops any running pass and the last result. Call it whenever the image changes, such as when
	 * the camera moves.
	 */
	reset() {

		this._abort?.();
		this._abort = null;

		this._texture?.dispose();
		this._texture = null;

		this._rawTexture?.destroy();
		this._rawTexture = null;

		this._disposeAuxImages();

		this._running = false;
		this._complete = false;
		this._failed = false;

	}

	dispose() {

		this.reset();
		this._unpackAuxKernel.dispose();

		// the networks hold the weights on the GPU, and a load may still be in flight
		for ( const key in this._unets ) {

			this._unets[ key ]?.then( unet => unet.dispose() );
			this._unets[ key ] = null;

		}

	}

	// Unpacks the path tracer's auxiliary target into albedo and normal textures, since oidn-webgpu
	// reads every input as the same kind as the color texture
	_unpackAux( aux ) {

		const { renderer, _unpackAuxKernel, _albedoTarget, _normalTarget } = this;
		const { width, height } = aux.image;

		_albedoTarget.setSize( width, height );
		_normalTarget.setSize( width, height );

		_unpackAuxKernel.auxTarget = aux;
		_unpackAuxKernel.albedoTarget = _albedoTarget;
		_unpackAuxKernel.normalTarget = _normalTarget;
		renderer.compute( _unpackAuxKernel.kernel, _unpackAuxKernel.getDispatchSize( width, height ) );

	}

	// the unpacked images only live for a pass
	_disposeAuxImages() {

		this._albedoTarget.dispose();
		this._normalTarget.dispose();

	}

	// loads each model once, with concurrent calls sharing the same promise
	_initUNet( aux ) {

		const key = aux ? 'aux' : 'color';
		if ( ! this._unets[ key ] ) {

			this._unets[ key ] = ( async () => {

				const device = this.renderer.backend.device;
				const url = aux ? this.auxWeightsUrl : this.colorWeightsUrl;

				if ( ! url ) {

					throw new Error( `OIDNDenoiser: no ${ aux ? 'auxWeightsUrl' : 'colorWeightsUrl' } was provided.` );

				}

				const options = { aux, hdr: true };
				if ( this.maxTileSize !== null ) options.maxTileSize = this.maxTileSize;
				if ( this.dynamicTile !== null ) options.dynamicTile = this.dynamicTile;

				return this.initUNetFromURL( url, { device }, options );

			} )();

		}

		return this._unets[ key ];

	}

	// Copies the denoiser's packed output buffer into a sampleable texture, using a compute pass
	// since copyBufferToTexture requires 256 byte row alignment.
	// TODO: remove the copy once oidn-webgpu can write into a caller-provided storage texture.
	_copyOutputToTexture( output, width, height ) {

		const device = this.renderer.backend.device;

		if ( ! this._resultPipeline ) {

			const module = device.createShaderModule( {
				code: /* wgsl */`
					@group( 0 ) @binding( 0 ) var<storage, read> src : array<vec4f>;
					@group( 0 ) @binding( 1 ) var dst : texture_storage_2d<rgba16float, write>;

					@compute @workgroup_size( 8, 8 )
					fn main( @builtin( global_invocation_id ) gid : vec3u ) {

						let dims = textureDimensions( dst );
						if ( gid.x >= dims.x || gid.y >= dims.y ) {

							return;

						}

						textureStore( dst, gid.xy, src[ gid.y * dims.x + gid.x ] );

					}
				`,
			} );

			this._resultPipeline = device.createComputePipeline( {
				layout: 'auto',
				compute: { module, entryPoint: 'main' },
			} );

		}

		if ( ! this._rawTexture || this._rawTexture.width !== width || this._rawTexture.height !== height ) {

			this._rawTexture?.destroy();
			this._rawTexture = device.createTexture( {
				size: [ width, height ],
				format: 'rgba16float',
				usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING,
			} );

			// ExternalTexture lets three sample a gpu texture it did not create. It has no image
			// behind it, so its size is set explicitly or "texture.width" reports zero.
			this._texture?.dispose();
			this._texture = new ExternalTexture( this._rawTexture );
			this._texture.image = { width, height };

		}

		const bindGroup = device.createBindGroup( {
			layout: this._resultPipeline.getBindGroupLayout( 0 ),
			entries: [
				{ binding: 0, resource: { buffer: output.data } },
				{ binding: 1, resource: this._rawTexture.createView() },
			],
		} );

		const encoder = device.createCommandEncoder();
		const pass = encoder.beginComputePass();
		pass.setPipeline( this._resultPipeline );
		pass.setBindGroup( 0, bindGroup );
		pass.dispatchWorkgroups( Math.ceil( width / 8 ), Math.ceil( height / 8 ) );
		pass.end();
		device.queue.submit( [ encoder.finish() ] );

	}

}
